
var tablinks = document.getElementsByClassName("tab-links");
var tabcontents = document.getElementsByClassName("tab-contents");
function opentab(tabname) {
    for (tablink of tablinks) {
        tablink.classList.remove("active-link")
    }
    for (tabcontent of tabcontents) {
        tabcontent.classList.remove("active-tab")
    }
    event.currentTarget.classList.add("active-link")
    document.getElementById(tabname).classList.add("active-tab")
}


var sidemenu = document.getElementById("sidemenu");

function openmenu() {
    sidemenu.style.right = "0"
}
function closemenu() {
    sidemenu.style.right = "-200px"
}

const scriptURL = 'https://script.google.com/macros/s/AKfycbydxmC5pV-3XN_wImtnf6Qqn_b7PEnIV1bPkrtQ9BOykghqi8DwgLl6_Jw2wXNNmtMx8Q/exec'
const form = document.forms['submit-to-google-sheet']
const msg = document.getElementById("msg")

form.addEventListener('submit', e => {
    e.preventDefault()
    fetch(scriptURL, { method: 'POST', body: new FormData(form) })
        .then(response => {
            msg.innerHTML = "Message sent successfully"
            setTimeout(function () {
                msg.innerHTML = ""
            }, 5000)
            form.reset()
        })
        .catch(error => console.error('Error!', error.message))
})



var icon = document.getElementById("icon");
var logo = document.querySelector(".logo");

icon.onclick = function () {
    document.body.classList.toggle("light-theme");

    // Change the logo dynamically
    if (document.body.classList.contains("light-theme")) {
        logo.src = "./images/lightlogo.png"; // Switch to light mode logo
        icon.src = "./images/moon.png";       // Change icon to a sun
    } else {
        logo.src = "./images/logo.png";      // Switch back to dark mode logo
        icon.src = "./images/sun.png";      // Change icon to a moon
    }
};
